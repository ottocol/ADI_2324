import {saludar} from './saludador.js'

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('mensaje').innerHTML = saludar()
})